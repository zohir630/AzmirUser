# Jogipal Somazkollan Foundation — User Site
GitHub Pages-এ আপলোড করুন (Settings → Pages → main / root)। কনটেন্ট অ্যাডমিন প্যানেল থেকে নিয়ন্ত্রিত হয়।
Authorized domains এ `<username>.github.io` যোগ করা ও Database Rules (admin zip-এর `database.rules.json`) Publish করা আবশ্যক।
